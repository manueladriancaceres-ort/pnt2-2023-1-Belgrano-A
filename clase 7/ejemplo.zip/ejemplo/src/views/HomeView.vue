<template>
  <ion-page>
    <h2>Home view</h2>
  </ion-page>
</template>

<script>
import {IonPage} from '@ionic/vue'
export default {
  components: { IonPage}
}
</script>