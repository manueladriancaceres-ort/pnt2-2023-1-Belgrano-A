<template>
  <ion-page>
    <h2>System</h2>
    <ion-content>
      <ion-list v-for="e in lista" :key="e.id">
        {{ e.id }} {{ e.desc }} 
      </ion-list>  
      <ion-input 
        label="id" label-placement="stacked" v-model="elemento.id"></ion-input>
      <ion-input 
        label="Descripcion" label-placement="stacked" v-model="elemento.desc"></ion-input>
      <ion-button @click="agregar"> Agregar a la lista </ion-button>
    </ion-content>  
    <ion-button @click="irahome">Ir a Home</ion-button>
  </ion-page>
</template>

<script>
import {IonPage, IonButton, IonContent, IonInput, IonList} from '@ionic/vue'

export default {
  components: { IonPage, IonButton, IonContent, IonInput, IonList},
  data() {
    return {
      lista: [{id:100,desc:'Silla'},{id:200,desc:'mesa'}],
      elemento: {}
    }
  },
  methods: {
    irahome() {
      this.$router.push("/")
    },
    agregar() {
      this.lista.push({...this.elemento})
    }
  }
}
</script>

<style>

</style>