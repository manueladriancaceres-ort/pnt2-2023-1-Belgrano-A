<template>
  <ion-page>
    <h2>System</h2>
    <button @click="irahome">Ir a Home</button>
  </ion-page>
</template>

<script>
import {IonPage} from '@ionic/vue'

export default {
  components: { IonPage},
  methods: {
    irahome() {
      this.$router.push("/")
    }
  }
}
</script>

<style>

</style>